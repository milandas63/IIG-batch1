package com.mobile;

public class Airtel implements Sim {
	public void dialing() {
		System.out.println("Dialing using Airtel");
	}
	
	public void data() {
		System.out.println("Use internet data using Airtel");
	}
}
