package com.mobile;

public class Vodaphone implements Sim {
	public void dialing() {
		System.out.println("Dialing using Vodaphone");
	}
	
	public void data() {
		System.out.println("Use internet data using Vodaphone");
	}
}
