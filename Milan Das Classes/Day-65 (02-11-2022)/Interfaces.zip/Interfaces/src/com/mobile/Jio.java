package com.mobile;

public class Jio implements Sim {
	public void dialing() {
		System.out.println("Dialing using Jio");
	}
	
	public void data() {
		System.out.println("Use internet data using Jio");
	}
}
