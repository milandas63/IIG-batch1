package com.mobile;

public interface Sim {
	public void dialing();
	public void data();
}
