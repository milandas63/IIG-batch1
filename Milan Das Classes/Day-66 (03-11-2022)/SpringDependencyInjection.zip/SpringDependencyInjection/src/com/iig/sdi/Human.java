package com.iig.sdi;

public class Human {

	public Heart heart;
	public Lungs lungs;
	
	public void setLungs(Lungs lungs) {
		this.lungs = lungs;
	}

	public void setHeart(Heart heart) {
		System.out.println("setter method used");
		this.heart = heart;
	}

	public void startPumping() {
		heart.pump();
	}

	public void breath() {
		lungs.inhale();
	}
}
