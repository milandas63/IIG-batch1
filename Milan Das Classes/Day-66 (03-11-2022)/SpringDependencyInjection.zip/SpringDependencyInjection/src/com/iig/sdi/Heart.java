package com.iig.sdi;

public class Heart {
	public void pump() {
		System.out.println("Heart is pumping - you are alive");
	}
}
