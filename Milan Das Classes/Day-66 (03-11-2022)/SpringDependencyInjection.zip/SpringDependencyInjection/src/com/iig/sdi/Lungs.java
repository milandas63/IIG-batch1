package com.iig.sdi;

public class Lungs {
	public void inhale() {
		System.out.println("Lungs is full");
	}
}
