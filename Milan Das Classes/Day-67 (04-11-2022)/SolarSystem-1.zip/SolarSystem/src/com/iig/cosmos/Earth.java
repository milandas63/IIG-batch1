package com.iig.cosmos;

public class Earth implements Planet {

	@Override
	public String getPlanetName() {
		return "EARTH";
	}

	@Override
	public boolean getLifeStatus() {
		return true;
	}

	@Override
	public long getSurfaceAreaKm() {
		return 510072000L;
	}

	@Override
	public long getLiquidAreaKm() {
		return 36174000000L;
	}
}
