package com.iig.cosmos;

public interface Planet {
	public String getPlanetName();
	public boolean getLifeStatus();
	public long getSurfaceAreaKm();
	public long getLiquidAreaKm();
}
