package com.iig.cosmos;

public class Jupiter  implements Planet {

	@Override
	public String getPlanetName() {
		return "JUPITER";
	}

	@Override
	public boolean getLifeStatus() {
		return false;
	}

	@Override
	public long getSurfaceAreaKm() {
		return 61420000000L;
	}

	@Override
	public long getLiquidAreaKm() {
		return 20000L;
	}
}
