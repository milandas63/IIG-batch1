package com.iig.cosmos;

public class SolarSystem {
	public Jupiter planet;

	public void setPlanet(Jupiter planet) {
		this.planet = planet;
		System.out.println("Setter Called...");
	}

	public void printPlanetData() {
		System.out.println("PLANET NAME IS " + planet.getPlanetName());
		System.out.println("Life status is " + (planet.getLifeStatus()?"Alive":"Dead"));
		System.out.println("Surface Area in Sq.KM. is " + planet.getSurfaceAreaKm());
		System.out.println("Liquid Area in Sq.KM. is " + planet.getLiquidAreaKm());
	}
}
