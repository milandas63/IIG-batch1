package com.iig.cosmos;

public class Mercury  implements Planet {

	@Override
	public String getPlanetName() {
		return "MERCURY";
	}

	@Override
	public boolean getLifeStatus() {
		return false;
	}

	@Override
	public long getSurfaceAreaKm() {
		return 78000000L;
	}

	@Override
	public long getLiquidAreaKm() {
		return 1289L;
	}
}
