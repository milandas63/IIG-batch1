package com.iig.cosmos;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Cosmos {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		//SolarSystem solsys = (SolarSystem) context.getBean("solsys");
		SolarSystem solsys = context.getBean("solsys",SolarSystem.class);
		solsys.printPlanetData();
	}

}
