package com.setter.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Team {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Company company = context.getBean("company", Company.class);
		company.printBatDetails();
		
//		Company company = new Company();
//		company.setBatModel("Kookaburra");
//		company.setBatLength(87);
//		company.printBatDetails();
	}
}
