package com.setter.injection;

// Setter Dependency Injection
public class Company {
	private String batModel;
	private int batLength;
	
	public void printBatDetails() {
		System.out.println("Model:  " + batModel);
		System.out.println("Length: " + batLength);
	}

	public void setBatModel(String batModel) {
		this.batModel = batModel;
		System.out.println("setBatModel() is called");
	}

	public void setBatLength(int batLength) {
		this.batLength = batLength;
		System.out.println("setBatLength() is called");
	}
}
