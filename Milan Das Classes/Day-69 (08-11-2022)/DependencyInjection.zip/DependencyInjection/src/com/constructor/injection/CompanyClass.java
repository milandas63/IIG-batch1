package com.constructor.injection;

// Constructor Dependency Injection
public class CompanyClass {
	private String batModel;
	private Behaviour behavior;
	private int batLength;

	public CompanyClass(String batModel, int batLength) {
		this.batModel = batModel;
		this.batLength = batLength;
		System.out.println("Constructor called");
	}
	
	public void setBehavior(Behaviour behavior) {
		this.behavior = behavior;
	}


	public void printBatDetails() {
		System.out.println("Model:  " + batModel);
		System.out.println("Length: " + batLength);
		System.out.println("Country:" + behavior.getCountry());
	}
}
