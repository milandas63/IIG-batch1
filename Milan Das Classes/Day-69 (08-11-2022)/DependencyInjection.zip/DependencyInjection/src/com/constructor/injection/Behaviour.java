package com.constructor.injection;

public class Behaviour {
	private String country;

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountry() {
		return country;
	}
}
