package teldir;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveNewContact
 */
@WebServlet("/SaveNewContact")
public class SaveNewContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveNewContact() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();

//			String oneColumn;
//			String[] values;
//			out.println("<body>");
//			Enumeration<String> enames = request.getParameterNames();
//			while(enames.hasMoreElements()) {
//				oneColumn = enames.nextElement();
//				values = request.getParameterValues(oneColumn);
//				out.println("<h2>" + oneColumn + " = " + values[0] + "</h2>");
//			}
//			out.println("</body>");

			String group_id = request.getParameter("group");
			String loc_id = request.getParameter("location");
			String cname = request.getParameter("cname");
			String mobile1 = request.getParameter("mobile1");
			String email1 = request.getParameter("email1");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir", "root", "");
			Statement stmt = conn.createStatement();
			System.out.println("INSERT INTO contact(group_id,location_id,contact_name,mobile_no1,email_id1) VALUES("+group_id+","+loc_id+",'"+cname+"','"+mobile1+"','"+email1+"')");
			stmt.executeUpdate("INSERT INTO contact(group_id,location_id,contact_name,mobile_no1,email_id1) VALUES("+group_id+","+loc_id+",'"+cname+"','"+mobile1+"','"+email1+"')");
			conn.close();
			out.println("<body>");
			out.println("<h1>Data is successfully saved</h1>");
			out.println("</body>");
		} catch(ClassNotFoundException e) {
			System.out.println(e);
		} catch(SQLException e) {
			System.out.println(e);
		} catch(Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
