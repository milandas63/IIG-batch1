package teldir;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EditRow extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public PrintWriter out;

	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException {
		out = res.getWriter();
		out.println("<h1>Design the edit page</h1>");
	}
}
