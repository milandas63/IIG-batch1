package learn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Validate extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		String user = req.getParameter("username");
		String pw = req.getParameter("password");
		try {
			PrintWriter out = res.getWriter();
			out.println(user);
			out.println(pw);
		} catch(IOException e) {
			
		}
	}
}
