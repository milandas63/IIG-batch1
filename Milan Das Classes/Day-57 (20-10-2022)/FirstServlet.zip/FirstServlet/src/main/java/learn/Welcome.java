package learn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter out;
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		try {
			out = res.getWriter();
			out.println("<h1>This is the first Servlet Program</h1>");
		} catch(IOException e) {
		} catch(Exception e) {
		}
	}

}
