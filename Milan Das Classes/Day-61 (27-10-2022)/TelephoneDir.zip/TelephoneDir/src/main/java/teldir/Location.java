package teldir;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Location extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public Connection conn;
	public Statement stmt;
	public ResultSet rs;
	public ResultSetMetaData rsmd;
	public PrintWriter out;

	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException {
		try {
			out = res.getWriter();
	
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("SELECT l.loc_id AS 'ID',l.loc_name AS 'NAME',l.loc_abbr AS 'ABBR',l.loc_state AS 'STATE',l.loc_country AS 'COUNTRY' FROM location AS l ORDER BY l.loc_id");
			rsmd = rs.getMetaData();
			int row = 0;
			
			out.println("<html>");
			out.println("<body>");
			out.println("<h1>Location Maintenance</h1>");
			out.println("<br><hr><br>");
			out.println("<table border='1'>");
	
			out.println("<tr>");
			for(int i=1; i<=rsmd.getColumnCount(); i++) {
				out.print("<th>"+rsmd.getColumnLabel(i)+"</th>");
			}
			out.println("</tr>");
	
			while(rs.next()) {
				row++;
				if(row%2==0) {
					out.println("<tr style='background-color:lightGray;'>");
				} else {
					out.println("<tr>");
				}
				for(int i=1; i<=rsmd.getColumnCount(); i++) {
					out.print("<td>"+rs.getString(i)+"</td>");
				}
				out.println("<td><a href='http://localhost:8080/TelephoneDir/editrow'><img src='edit.png' width='12' height='12'></a></td>");
				out.println("<td><a><img src='delete.png' width='12' height='12'></a></td>");
				out.println("</tr>");
			}
			
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
	
		} catch(IOException e) {
			System.err.println(e);
		} catch(ClassNotFoundException e) {
			System.err.println(e);
		} catch(SQLException e) {
			System.err.println(e);
		}
	}
}
