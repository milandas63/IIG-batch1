package telephone_directory;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddNewContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Connection conn;
	public Statement stmt;
	public ResultSet rs;
	public ResultSetMetaData rsmd;
	public PrintWriter out;
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) {
		try {
			out = res.getWriter();

			String group_id = req.getParameter("group1");
			String loc_id = req.getParameter("group2");
			String cname = req.getParameter("cname");
			String mobile1 = req.getParameter("mobile1");
			String email1 = req.getParameter("email1");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir", "root", "");
			Statement stmt = conn.createStatement();
			System.out.println("INSERT INTO contact(group_id,location_id,contact_name,mobile_no1,email_id1) VALUES("+group_id+","+loc_id+",'"+cname+"','"+mobile1+"','"+email1+"')");
			stmt.executeUpdate("INSERT INTO contact(group_id,location_id,contact_name,mobile_no1,email_id1) VALUES("+group_id+","+loc_id+",'"+cname+"','"+mobile1+"','"+email1+"')");
			conn.close();
			out.println("<body>");
			out.println("<h1>Data is successfully saved</h1>");
			out.println("</body>");
		} catch(ClassNotFoundException e) {
			System.out.println(e);
		} catch(SQLException e) {
			System.out.println(e);
		} catch(Exception e) {
			System.out.println(e);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
