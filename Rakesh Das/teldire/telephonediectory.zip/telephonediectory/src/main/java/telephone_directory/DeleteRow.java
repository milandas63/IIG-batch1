package telephone_directory;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteRow extends HttpServlet {
private static final long serialVersionUID = 1L;
	
	
	public Connection conn;
	public Statement stmt;
	public ResultSet rs;
	public ResultSetMetaData rsmd;
	public PrintWriter out;
	

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) {
		String row = req.getParameter("drow");
		
		try {
			out = res.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			conn.createStatement().executeUpdate("delete from contact where contact_id="+row);
			conn.close();
			out.println("<html>");
			out.println("<body background='d.jpg'>");
			out.println("<h1 style='color:#E53935;'>Selected Row Has Been Deleted....</h1>");
			out.println("<br><hr>");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("SELECT c.contact_id AS 'ID',c.contact_name AS 'NAME',cg.group_name AS 'GROUP',l.loc_name AS 'LOCATION',c.mobile_no1 AS 'MOB-NO',c.email_id1 AS 'EMAIL' FROM contact AS c LEFT JOIN contact_group AS cg ON c.group_id=cg.group_id LEFT JOIN location AS l ON c.location_id=l.loc_id ORDER BY c.contact_id");
			rsmd = rs.getMetaData();
			out.println("<table border='1'>");

			out.println("<tr>");
			for(int i=1; i<=rsmd.getColumnCount(); i++) {
				out.print("<th style='background-color:red;'>"+rsmd.getColumnLabel(i)+"</th>");
			}
			out.println("</tr>");

			while(rs.next()) {
				out.println("<tr>");
				for(int i=1; i<=rsmd.getColumnCount(); i++) {
					if(i%2==0) {
						out.print("<td style='background-color:lightGray;'>"+rs.getString(i)+"</td>");
					} else {
						out.print("<td style='background-color:yellow;'>"+rs.getString(i)+"</td>");
					}
				}
				out.println("</tr>");
			}
			
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
		} catch(ClassNotFoundException e) {
			System.out.println(e);
		} catch(SQLException e) {
			System.out.println(e);
		} catch(Exception e) {
			System.out.println(e);
		}
	}
	}


