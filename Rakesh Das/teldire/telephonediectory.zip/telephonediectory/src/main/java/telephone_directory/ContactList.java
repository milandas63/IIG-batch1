package telephone_directory;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContactList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Connection conn;
	public Statement stmt;
	public ResultSet rs;
	public ResultSetMetaData rsmd;
	public PrintWriter out;
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) {
		try {
			out = res.getWriter();

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("SELECT c.contact_id AS 'ID',c.contact_name AS 'NAME',cg.group_name AS 'GROUP',l.loc_name AS 'LOCATION',c.mobile_no1 AS 'MOB-NO',c.email_id1 AS 'EMAIL' FROM contact AS c LEFT JOIN contact_group AS cg ON c.group_id=cg.group_id LEFT JOIN location AS l ON c.location_id=l.loc_id ORDER BY c.contact_id");
			rsmd = rs.getMetaData();
			
			out.println("<html>");
			out.println("<head>");
			out.println("<style>");
			out.println(".center {");
			out.println("margin-left: auto;");
			out.println("margin-right: auto;");
			out.println("}");
			out.println("</style>");
			out.println("</head>");
			out.println("<body style='background-color:#40E0D0;'>");
			out.println("<h2>Contact Maintenance</h2>");
			out.println("<hr>");
			out.println("<a href='addNewContact.jsp'>");
			out.println("<img src='ab.png' style='float:right;width:50px;height:50px;'>");
			out.println("</a>");
			out.println("<br><br><br>");
			out.println("<a href='editcontact.jsp'>");
			out.println("<img src='abt1jpg.jpg' style='float:right;width:50px;height:50px;'>");
			out.println("</a>");
			out.println("<br><br><br>");
			out.println("<a href='deletecontact.jsp'>");
			out.println("<img src='images3.png' style='float:right;width:50px;height:50px;'>");
			out.println("</a>");
			out.println("<table class='center' border='1'>");

			out.println("<tr>");
			for(int i=1; i<=rsmd.getColumnCount(); i++) {
				out.print("<th>"+rsmd.getColumnLabel(i)+"</th>");
			}
			out.println("</tr>");

			while(rs.next()) {
				out.println("<tr>");
				for(int i=1; i<=rsmd.getColumnCount(); i++) {
					if(i%2==0) {
						out.print("<td style='background-color:lightGray;'>"+rs.getString(i)+"</td>");
					} else {
						out.print("<td>"+rs.getString(i)+"</td>");
					}
				}
				out.println("<td><a href='http://localhost:8080/telephonediectory/editcontact.jsp'><img src='edit.png' width='12' height='12'></a></td>");
				out.println("<td><a href='http://localhost:8080/telephonediectory/deletecontact.jsp'><img src='delete.png' width='12' height='12'></a></td>");
				out.println("</tr>");
			}
			
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");

		} catch(ClassNotFoundException e) {
			System.err.println(e);
		} catch(IOException e) {
			System.err.println(e);
		} catch(SQLException e) {
			System.err.println(e);
		}
	}
	
}
