package telephone_directory;


import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class EditRow extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public Connection conn;
	public Statement stmt;
	public PreparedStatement pstmt;
	public ResultSet rs;
	public ResultSetMetaData rsmd;
	public PrintWriter out;
	

	public void service(HttpServletRequest req, HttpServletResponse res) {
		String CID = req.getParameter("cid");
		String GID = req.getParameter("gid");
		String LID = req.getParameter("lid");
		String MN = req.getParameter("mn");
		String EID = req.getParameter("eid");
		String CDT = req.getParameter("cdt");
		
		try {
			out = res.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			pstmt = conn.prepareStatement("UPDATE contact SET contact_name=?,group_id=?,location_id=?,mobile_no1=?,email_id1=? WHERE contact_id=?",ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pstmt.setString(1, CDT);
			pstmt.setString(2,GID);
			pstmt.setString(3, LID);
			pstmt.setString(4,MN);
			pstmt.setString(5,EID);
			pstmt.setString(6,CID);
			pstmt.executeUpdate();
			conn.close();
			
			out.println("<html>");
			out.println("<body style='background-color:#99FF33;'>");
			out.println("<h3>Entered Data Is Successfully Updated...</h3>");
			out.println("<hr><br>");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teldir","root","");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("SELECT c.contact_id AS 'ID',c.contact_name AS 'NAME',cg.group_name AS 'GROUP',l.loc_name AS 'LOCATION',c.mobile_no1 AS 'MOB-NO',c.email_id1 AS 'EMAIL' FROM contact AS c LEFT JOIN contact_group AS cg ON c.group_id=cg.group_id LEFT JOIN location AS l ON c.location_id=l.loc_id ORDER BY c.contact_id");
			rsmd = rs.getMetaData();
			
			out.println("<html>");
			out.println("<body>");
			out.println("<table border='1'>");

			out.println("<tr>");
			for(int i=1; i<=rsmd.getColumnCount(); i++) {
				out.print("<th>"+rsmd.getColumnLabel(i)+"</th>");
			}
			out.println("</tr>");

			while(rs.next()) {
				out.println("<tr>");
				for(int i=1; i<=rsmd.getColumnCount(); i++) {
					if(i%2==0) {
						out.print("<td style='background-color:lightGray;'>"+rs.getString(i)+"</td>");
					} else {
						out.print("<td>"+rs.getString(i)+"</td>");
					}
				}
				out.println("</tr>");
			}
			
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
			out.println("</body>");
			out.println("</html>");
			
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}catch(SQLException e) {
			System.out.println(e);
		}catch(Exception e) {
			System.out.println(e);
		}
		}
	}

